import React from 'react';
import Grid from './Grid'; // Import the Grid component
import './App.css';

function App() {
  return (
    <div className="App">
      <h1>Crossover Grid Game</h1>
      <div className="game-container">
        <Grid /> {/* Include the Grid component here */}
      </div>
      {/* You can add other components like rarity score, reset button, etc., here */}
    </div>
  );
}

export default App;
