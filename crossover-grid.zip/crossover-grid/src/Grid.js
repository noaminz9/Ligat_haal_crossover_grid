import React, { useState } from 'react';
import Square from './Square';


function Grid() {
    const [squares, setSquares] = useState(Array(3).fill(Array(3).fill(null)));
  const rows = [0, 1, 2];
  const columns = [0, 1, 2];

  return (
    <table id="game-grid">
      <tbody>
        {rows.map((row) => (
          <tr key={row}>
            {columns.map((col) => (
              <Square key={col} value={squares[row][col]} row={row} col={col} onClick={() => handleSquareClick(row, col)} />
            ))}
          </tr>
        ))}
      </tbody>
    </table>
  );

  function handleSquareClick(row, col) {
    // Create a copy of the squares array
    const newSquares = squares.map((r) => r.slice());

    // Update the clicked square (you can set a value or call a function to determine the value)
    newSquares[row][col] = 'X'; // Example value

    // Update the state
    setSquares(newSquares);
  }
}

export default Grid;
